#!/usr/bin/env -S scala -cp "joern-cli/target/joern-cli.jar:lib/*" -savecompiled

import io.shiftleft.codepropertygraph.Cpg
import io.shiftleft.codepropertygraph.generated.nodes._
import io.shiftleft.semanticcpg.language._
import io.shiftleft.semanticcpg.dotgenerator.DotCfgGenerator
import io.shiftleft.semanticcpg.dotgenerator.DotDdgGenerator

import java.io.{File, PrintWriter}
import java.nio.file.{Files, Paths}
import scala.util.{Try, Success, Failure}
import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import spray.json._
import scala.language.postfixOps

object JsonProtocol extends DefaultJsonProtocol {
  implicit object NodeJsonFormat extends JsonFormat[StoredNode] {
    def write(node: StoredNode) = JsObject(
      "id" -> JsNumber(node.id),
      "label" -> JsString(node.label),
      "code" -> JsString(node.code),
      "lineNumber" -> node.lineNumber.fold[JsValue](JsNull)(n => JsNumber(n)),
      "order" -> JsNumber(node.order)
    )

    def read(value: JsValue) = throw new UnsupportedOperationException("Reading nodes not supported")
  }

  implicit val cfgEdgeFormat: JsonFormat[CFGEdge] = jsonFormat5(CFGEdge.apply)
  implicit val dfgEdgeFormat: JsonFormat[DFGEdge] = jsonFormat5(DFGEdge.apply)
  implicit val astNodeFormat: JsonFormat[ASTNode] = jsonFormat7(ASTNode.apply)
  implicit val functionInfoFormat: JsonFormat[FunctionInfo] = jsonFormat8(FunctionInfo.apply)
  implicit val vulnerabilityFormat: JsonFormat[Vulnerability] = jsonFormat5(Vulnerability.apply)
  implicit val analysisResultFormat: JsonFormat[AnalysisResult] = jsonFormat7(AnalysisResult.apply)
}

import JsonProtocol._

case class FunctionInfo(
  name: String,
  fullName: String,
  signature: String,
  lineNumber: Option[Int],
  endLineNumber: Option[Int],
  cyclomaticComplexity: Int,
  numberOfStatements: Int,
  parameters: List[String]
)

case class CFGEdge(
  sourceId: Long,
  targetId: Long,
  sourceCode: String,
  targetCode: String,
  edgeType: String
)

case class DFGEdge(
  sourceId: Long,
  targetId: Long,
  sourceCode: String,
  targetCode: String,
  variable: String
)

case class ASTNode(
  id: Long,
  label: String,
  code: String,
  order: Int,
  lineNumber: Option[Int],
  parentId: Option[Long],
  childrenIds: List[Long]
)

case class Vulnerability(
  pattern: String,
  severity: String,
  lineNumber: Option[Int],
  code: String,
  description: String
)

case class AnalysisResult(
  fileName: String,
  timestamp: Long,
  functions: List[FunctionInfo],
  cfgEdges: List[CFGEdge],
  dfgEdges: List[DFGEdge],
  astNodes: List[ASTNode],
  vulnerabilities: List[Vulnerability],
  metrics: Map[String, Any] = Map.empty
)

object CPGAnalyzer {

  case class Config(
    inputFile: String = "",
    outputFile: String = "analysis_result.json",
    visualize: Boolean = false,
    format: String = "json",
    verbose: Boolean = false,
    maxFunctions: Option[Int] = None
  )

  def parseArgs(args: Array[String]): Config = {
    val parser = new scopt.OptionParser[Config]("cpg-analyzer") {
      head("CPG Analyzer", "1.0.0")

      arg[String]("<cpg-file>")
        .required()
        .action((x, c) => c.copy(inputFile = x))
        .text("CPG path (.cpg.bin)")

      opt[String]('o', "output")
        .action((x, c) => c.copy(outputFile = x))
        .text("outpath ( analysis_result.json)")

      opt[Unit]('v', "visualize")
        .action((_, c) => c.copy(visualize = true))
        .text("pic")

      opt[String]("format")
        .action((x, c) => c.copy(format = x))
        .text("out format: json, csv, dot (默认: json)")

      opt[Unit]("verbose")
        .action((_, c) => c.copy(verbose = true))
        .text("details")

      opt[Int]("max-functions")
        .action((x, c) => c.copy(maxFunctions = Some(x)))
        .text("max functions")

      help("help").text("help")

      note("""
eg:
  ./analyze_cpg.scala program.cpg.bin
  ./analyze_cpg.scala program.cpg.bin --output results.json --visualize
  ./analyze_cpg.scala program.cpg.bin --format csv --verbose
      """)
    }

    parser.parse(args, Config()) match {
      case Some(config) => config
      case None =>
        System.exit(1)
        Config()
    }
  }



    val config = parseArgs(args)

    if (!Files.exists(Paths.get(config.inputFile))) {
      println(s"bug: ${config.inputFile}")
      System.exit(1)
    }

    println(s"${config.inputFile}")
    println(s"out:${config.outputFile}")
    println(s"格式: ${config.format.toUpperCase}")


    //CPG
    analyzeCPG(config)
  }

  def analyzeCPG(config: Config): Unit = {
    val startTime = System.currentTimeMillis()

    Try {
      println("CPG")
      val cpg = Cpg.loadGraph(config.inputFile)

      try {
        // extract information
        println("function")
        val functions = extractFunctions(cpg, config.maxFunctions)

        println("CFG")
        val cfgEdges = extractCFGEdges(cpg)

        println("DFG")
        val dfgEdges = extractDFGEdges(cpg)

        println("AST")
        val astNodes = extractASTNodes(cpg)

        println("detect vul")
        val vulnerabilities = detectVulnerabilities(cpg)

        val metrics = calculateMetrics(cpg, functions, cfgEdges, dfgEdges, astNodes, vulnerabilities)

        //
        val result = AnalysisResult(
          fileName = config.inputFile,
          timestamp = System.currentTimeMillis(),
          functions = functions,
          cfgEdges = cfgEdges,
          dfgEdges = dfgEdges,
          astNodes = astNodes,
          vulnerabilities = vulnerabilities,
          metrics = metrics
        )

        // save
        saveResults(result, config)

        if (config.visualize) {
          generateVisualization(cpg, config)
        }

        printSummary(result, config, startTime)

      } finally {
        cpg.close()
        println("CPG已关闭")
      }

    } match {
      case Success(_) =>
        println("ok")

      case Failure(exception) =>
        println(s"lose: ${exception.getMessage}")
        exception.printStackTrace()
        System.exit(1)
    }
  }

  def extractFunctions(cpg: Cpg, maxFunctions: Option[Int]): List[FunctionInfo] = {
    val methodTraversal = cpg.method
    val methods = maxFunctions match {
      case Some(max) => methodTraversal.take(max).l
      case None => methodTraversal.l
    }

    methods.map { method =>
      FunctionInfo(
        name = method.name,
        fullName = method.fullName,
        signature = method.signature,
        lineNumber = method.lineNumber,
        endLineNumber = method.lineNumberEnd,
        cyclomaticComplexity = method.cyclomaticNumber.getOrElse(0),
        numberOfStatements = method.numberOfLines.getOrElse(0),
        parameters = method.parameter.name.l
      )
    }
  }

  def extractCFGEdges(cpg: Cpg): List[CFGEdge] = {
    val edges = ListBuffer[CFGEdge]()

    cpg.method.foreach { method =>
      //CFG
      method.cfgNext.foreach { edge =>
        val src = edge.src
        val dst = edge.dst

        edges += CFGEdge(
          sourceId = src.id,
          targetId = dst.id,
          sourceCode = truncateCode(src.code),
          targetCode = truncateCode(dst.code),
          edgeType = "CFG_NEXT"
        )
      }

      //
      method.ast.isControlStructure.foreach { control =>
        control.condition.foreach { cond =>
          edges += CFGEdge(
            sourceId = control.id,
            targetId = cond.id,
            sourceCode = truncateCode(control.code),
            targetCode = truncateCode(cond.code),
            edgeType = "CONDITIONAL"
          )
        }
      }

      // methods
      method.call.foreach { call =>
        edges += CFGEdge(
          sourceId = method.id,
          targetId = call.id,
          sourceCode = s"METHOD: ${method.name}",
          targetCode = truncateCode(call.code),
          edgeType = "CALL"
        )
      }
    }

    edges.toList
  }

  def extractDFGEdges(cpg: Cpg): List[DFGEdge] = {
    val edges = ListBuffer[DFGEdge]()

    cpg.method.foreach { method =>

      method.dfgEdges.foreach { edge =>
        val src = edge.src
        val dst = edge.dst

        val variable = extractVariableName(src, dst)

        edges += DFGEdge(
          sourceId = src.id,
          targetId = dst.id,
          sourceCode = truncateCode(src.code),
          targetCode = truncateCode(dst.code),
          variable = variable
        )
      }

      //
      method.local.foreach { local =>
        val uses = local.uses.l
        val defs = local.refs.l

        if (uses.nonEmpty && defs.nonEmpty) {
          for {
            d <- defs.headOption
            u <- uses.headOption
          } {
            edges += DFGEdge(
              sourceId = d.id,
              targetId = u.id,
              sourceCode = truncateCode(d.code),
              targetCode = truncateCode(u.code),
              variable = local.name
            )
          }
        }
      }
    }

    edges.toList
  }

  def extractASTNodes(cpg: Cpg): List[ASTNode] = {
    val nodes = ListBuffer[ASTNode]()
    val childrenMap = mutable.Map[Long, List[Long]]().withDefaultValue(List())

    // create
    cpg.method.ast.foreach { node =>
      node._astIn.nextOption().foreach { parent =>
        childrenMap(parent.id) = node.id :: childrenMap(parent.id)
      }
    }

    // creat node
    cpg.method.ast.foreach { node =>
      val parent = node._astIn.nextOption()

      nodes += ASTNode(
        id = node.id,
        label = node.label,
        code = truncateCode(node.code),
        order = node.order,
        lineNumber = node.lineNumber,
        parentId = parent.map(_.id),
        childrenIds = childrenMap(node.id).reverse
      )
    }

    nodes.sortBy(_.id).toList
  }

  def detectVulnerabilities(cpg: Cpg): List[Vulnerability] = {
    val vulns = ListBuffer[Vulnerability]()

        cpg.call.name("strcpy|strcat|sprintf|gets").foreach { call =>
      vulns += Vulnerability(
        pattern = "BUFFER_OVERFLOW",
        severity = "HIGH",
        lineNumber = call.lineNumber,
        code = call.code,
        description = "unsecurity"
      )
    }

    cpg.call.name("printf|sprintf|fprintf|snprintf").foreach { call =>
      if (call.argument.code.exists(_.contains("%"))) {
        vulns += Vulnerability(
          pattern = "FORMAT_STRING",
          severity = "HIGH",
          lineNumber = call.lineNumber,
          code = call.code,
          description = "may_strings"
        )
      }
    }

    cpg.call.name("malloc|calloc|realloc").foreach { call =>
      if (call.argument.size > 0) {
        val sizeArg = call.argument(0)
        if (sizeArg.code.matches(".*\\+.*|.*\\*.*|.*-.*")) {
          vulns += Vulnerability(
            pattern = "INTEGER_OVERFLOW",
            severity = "MEDIUM",
            lineNumber = call.lineNumber,
            code = call.code,
            description = "dyna"
          )
        }
      }
    }

    cpg.call.name("malloc|calloc|strdup").foreach { call =>
      val hasFree = call.method.call.name("free").nonEmpty
      if (!hasFree) {
        vulns += Vulnerability(
          pattern = "MEMORY_LEAK",
          severity = "MEDIUM",
          lineNumber = call.lineNumber,
          code = call.code,
          description = "nc"
        )
      }
    }

    cpg.call.name("\\*|->").foreach { call =>
      call.argument.foreach { arg =>
        if (arg.code.matches(".*NULL|null.*|0")) {
          vulns += Vulnerability(
            pattern = "NULL_DEREFERENCE",
            severity = "HIGH",
            lineNumber = call.lineNumber,
            code = call.code,
            description = "maybe null"
          )
        }
      }
    }

    vulns.toList
  }

  def calculateMetrics(
    cpg: Cpg,
    functions: List[FunctionInfo],
    cfgEdges: List[CFGEdge],
    dfgEdges: List[DFGEdge],
    astNodes: List[ASTNode],
    vulnerabilities: List[Vulnerability]
  ): Map[String, Any] = {

    val totalFunctions = functions.length
    val totalCFGEdges = cfgEdges.length
    val totalDFGEdges = dfgEdges.length
    val totalASTNodes = astNodes.length
    val totalVulnerabilities = vulnerabilities.length

    val complexities = functions.map(_.cyclomaticComplexity)
    val avgComplexity = if (complexities.nonEmpty)
      complexities.sum.toDouble / complexities.length
    else 0.0
    val maxComplexity = if (complexities.nonEmpty) complexities.max else 0

    val sizes = functions.map(_.numberOfStatements)
    val avgSize = if (sizes.nonEmpty) sizes.sum.toDouble / sizes.length else 0.0
    val maxSize = if (sizes.nonEmpty) sizes.max else 0

    val highSeverity = vulnerabilities.count(_.severity == "HIGH")
    val mediumSeverity = vulnerabilities.count(_.severity == "MEDIUM")
    val lowSeverity = vulnerabilities.count(_.severity == "LOW")

    Map(
      "basic" -> Map(
        "total_functions" -> totalFunctions,
        "total_cfg_edges" -> totalCFGEdges,
        "total_dfg_edges" -> totalDFGEdges,
        "total_ast_nodes" -> totalASTNodes,
        "total_vulnerabilities" -> totalVulnerabilities
      ),
      "complexity" -> Map(
        "average" -> avgComplexity,
        "maximum" -> maxComplexity,
        "distribution" -> complexities.groupBy(identity).map { case (k, v) => k -> v.length }
      ),
      "function_size" -> Map(
        "average_statements" -> avgSize,
        "maximum_statements" -> maxSize
      ),
      "vulnerability_severity" -> Map(
        "high" -> highSeverity,
        "medium" -> mediumSeverity,
        "low" -> lowSeverity
      ),
      "vulnerability_patterns" -> vulnerabilities.groupBy(_.pattern).map { case (k, v) =>
        k -> v.length
      }
    )
  }

  def saveResults(result: AnalysisResult, config: Config): Unit = {
    val outputPath = Paths.get(config.outputFile)
    val parentDir = outputPath.getParent
    if (parentDir != null) {
      Files.createDirectories(parentDir)
    }

    config.format.toLowerCase match {
      case "json" =>
        saveAsJson(result, outputPath.toString)

      case "csv" =>
        saveAsCSV(result, outputPath.toString)

      case "dot" =>
        // DOT
        saveAsJson(result, outputPath.toString.replace(".dot", ".json"))

      case _ =>
        saveAsJson(result, outputPath.toString)
    }

    println(s"${outputPath.toAbsolutePath}")
  }

  def saveAsJson(result: AnalysisResult, filename: String): Unit = {
    val writer = new PrintWriter(new File(filename))
    try {
      val json = result.toJson.prettyPrint
      writer.write(json)
    } finally {
      writer.close()
    }
  }

  def saveAsCSV(result: AnalysisResult, filename: String): Unit = {
    val writer = new PrintWriter(new File(filename))
    try {
      writer.println("=== FUNCTIONS ===")
      writer.println("Name,Complexity,Statements,Parameters")
      result.functions.foreach { f =>
        writer.println(s"${f.name},${f.cyclomaticComplexity},${f.numberOfStatements},\"${f.parameters.mkString(";")}\"")
      }

      if (result.vulnerabilities.nonEmpty) {
        writer.println("\n=== VULNERABILITIES ===")
        writer.println("Pattern,Severity,Line,Description")
        result.vulnerabilities.foreach { v =>
          val line = v.lineNumber.getOrElse("N/A")
          writer.println(s"${v.pattern},${v.severity},$line,\"${v.description}\"")
        }
      }

      writer.println("\n=== METRICS ===")
      writer.println("Metric,Value")
      result.metrics.get("basic").foreach { basic =>
        basic.asInstanceOf[Map[String, Any]].foreach { case (k, v) =>
          writer.println(s"$k,$v")
        }
      }

    } finally {
      writer.close()
    }
  }

  def generateVisualization(cpg: Cpg, config: Config): Unit = {
    println("get pic")

    // CFG
    cpg.method.foreach { method =>
      try {
        val dotCfg = DotCfgGenerator.dotCfg(method)
        val cfgFile = s"${method.name}_cfg.dot"
        Files.write(Paths.get(cfgFile), dotCfg.getBytes())
        println(s"  CFG: $cfgFile")

        // PNG
        if (System.getProperty("os.name").toLowerCase.contains("linux")) {
          Try {
            val pngFile = s"${method.name}_cfg.png"
            val cmd = s"dot -Tpng $cfgFile -o $pngFile"
            Runtime.getRuntime.exec(cmd).waitFor()
            println(s"  PNG: $pngFile")
          }
        }
      } catch {
        case e: Exception => println(s"  no CFG: ${e.getMessage}")
      }
    }
  }

  def printSummary(result: AnalysisResult, config: Config, startTime: Long): Unit = {
    val duration = (System.currentTimeMillis() - startTime) / 1000.0

    println("\n" + "="*70)
    println("abstract")
    println("="*70)
    println(s"wj: ${result.fileName}")
    println(s"time: ${duration}秒")
    println(s"stamper: ${new java.util.Date(result.timestamp)}")
    println()

    println(s"functions: ${result.functions.length}")
    if (result.functions.nonEmpty) {
      println("front 5:")
      result.functions.take(5).foreach { f =>
        println(s"  ${f.name} - fzd: ${f.cyclomaticComplexity}, " +
                s"sentence: ${f.numberOfStatements}, row: ${f.lineNumber.getOrElse("N/A")}")
      }
    }

    println(s"\nCFG边数量: ${result.cfgEdges.length}")
    println(s"DFG边数量: ${result.dfgEdges.length}")
    println(s"AST节点数量: ${result.astNodes.length}")


    //
    val basicMetrics = result.metrics.get("basic").asInstanceOf[Option[Map[String, Any]]]
    basicMetrics.foreach { metrics =>
      println("\nzb:")
      metrics.foreach { case (k, v) =>
        println(s"  $k: $v")
      }
    }

    println("="*70)
  }

  // tools
  private def truncateCode(code: String, maxLength: Int = 100): String = {
    if (code.length <= maxLength) code
    else code.take(maxLength) + "..."
  }

  private def extractVariableName(src: StoredNode, dst: StoredNode): String = {
    // extract
    val srcName = extractNameFromNode(src)
    val dstName = extractNameFromNode(dst)

    if (srcName.nonEmpty) srcName
    else if (dstName.nonEmpty) dstName
    else "unknown_variable"
  }

  private def extractNameFromNode(node: StoredNode): String = {
    node match {
      case n: Identifier => n.name
      case n: Local => n.name
      case n: MethodParameterIn => n.name
      case _ => ""
    }
  }
}

// run
if (!sys.props.contains("testing")) {
  CPGAnalyzer.main(args)
}