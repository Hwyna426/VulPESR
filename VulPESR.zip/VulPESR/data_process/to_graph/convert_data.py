import json
import os
import sys
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional, Union, Tuple
from dataclasses import dataclass, asdict, field
import logging
from datetime import datetime
import textwrap
import re
from collections import defaultdict
import hashlib

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('alpaca_converter.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@dataclass
class AlpacaItem:
    """Alpaca format data item"""
    instruction: str
    input: str
    output: str
    index: int
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CodeAnalysis:
    """Code analysis data structure"""
    source_code: str
    function_name: str
    cfg_edges: List[Dict[str, Any]]
    dfg_edges: List[Dict[str, Any]]
    ast_nodes: List[Dict[str, Any]]
    vulnerabilities: List[Dict[str, Any]]
    metrics: Dict[str, Any]
    filename: Optional[str] = None
    language: str = "c"


class AlpacaConverter:
    """Alpaca format converter"""

    def __init__(
            self,
            model_type: str = "codellama",
            max_input_length: int = 2048,
            include_visualization: bool = False,
            task_type: str = "code_understanding"
    ):
        """
        Initialize converter

        Args:
            model_type: Target model type (codellama, alpaca, vicuna, etc.)
            max_input_length: Maximum input length
            include_visualization: Whether to include visualization descriptions
            task_type: Task type (code_understanding, vulnerability_detection, code_generation)
        """
        self.model_type = model_type
        self.max_input_length = max_input_length
        self.include_visualization = include_visualization
        self.task_type = task_type

        # Task templates
        self.task_templates = {
            "code_understanding": {
                "instruction": "Analyze the following C code and its control flow graph, data flow graph, and abstract syntax tree.",
                "output_prefix": "Based on the code analysis, I can provide the following insights:\n"
            },
            "vulnerability_detection": {
                "instruction": "Detect potential vulnerabilities in the following C code by analyzing its control flow, data flow, and AST structure.",
                "output_prefix": "Vulnerability Analysis:\n"
            },
            "code_summarization": {
                "instruction": "Summarize the functionality of the following C code based on its CFG, DFG, and AST analysis.",
                "output_prefix": "Code Summary:\n"
            },
            "code_generation": {
                "instruction": "Given the control flow and data flow requirements, generate equivalent C code.",
                "output_prefix": "Generated Code:\n"
            }
        }

        logger.info(f"Initialized Alpaca Converter - Model: {model_type}, Task: {task_type}")

    def convert_analysis_to_alpaca(
            self,
            analysis: CodeAnalysis,
            index: int
    ) -> AlpacaItem:
        """
        Convert single code analysis to Alpaca format

        Args:
            analysis: Code analysis result
            index: Data index

        Returns:
            AlpacaItem: Alpaca format data item
        """
        # Build input text
        input_text = self._build_input_text(analysis)

        # Build output text
        output_text = self._build_output_text(analysis)

        # Get instruction
        instruction = self._get_instruction(analysis)

        # Build metadata
        metadata = self._build_metadata(analysis, index)

        # Truncate if too long
        if len(input_text) > self.max_input_length:
            input_text = self._truncate_input(input_text, analysis)
            logger.warning(f"Input text too long, truncated (Index: {index})")

        return AlpacaItem(
            instruction=instruction,
            input=input_text,
            output=output_text,
            index=index,
            metadata=metadata
        )

    def _build_input_text(self, analysis: CodeAnalysis) -> str:
        """Build input text"""
        sections = []

        # 1. Code section
        code_section = f"""## Source Code
```c
{analysis.source_code}
```"""
        sections.append(code_section)

        # 2. AST summary
        ast_summary = self._format_ast_summary(analysis.ast_nodes)
        sections.append(f"## Abstract Syntax Tree (AST) Summary\n{ast_summary}")

        # 3. CFG summary
        cfg_summary = self._format_cfg_summary(analysis.cfg_edges)
        sections.append(f"## Control Flow Graph (CFG) Summary\n{cfg_summary}")

        # 4. DFG summary
        dfg_summary = self._format_dfg_summary(analysis.dfg_edges)
        sections.append(f"## Data Flow Graph (DFG) Summary\n{dfg_summary}")

        # 5. Metrics
        metrics_text = self._format_metrics(analysis.metrics)
        sections.append(f"## Code Metrics\n{metrics_text}")

        # 6. Function information
        if analysis.function_name and analysis.function_name != "unknown":
            sections.append(
                f"## Function Information\n- Function: {analysis.function_name}\n- Language: {analysis.language}")

        # 7. Visualization description (optional)
        if self.include_visualization:
            viz_description = self._generate_visualization_description(analysis)
            sections.append(f"## Graph Visualization Description\n{viz_description}")

        return "\n\n".join(sections)

    def _build_output_text(self, analysis: CodeAnalysis) -> str:
        """Build output text"""
        output_parts = []

        # Basic analysis
        output_parts.append(self.task_templates[self.task_type]["output_prefix"])

        # 1. Function analysis
        func_analysis = self._analyze_function(analysis)
        output_parts.append(f"### 1. Function Analysis\n{func_analysis}")

        # 2. Control flow analysis
        cfg_analysis = self._analyze_control_flow(analysis.cfg_edges)
        output_parts.append(f"### 2. Control Flow Analysis\n{cfg_analysis}")

        # 3. Data flow analysis
        dfg_analysis = self._analyze_data_flow(analysis.dfg_edges)
        output_parts.append(f"### 3. Data Flow Analysis\n{dfg_analysis}")

        # 4. Complexity analysis
        complexity_analysis = self._analyze_complexity(analysis.metrics)
        output_parts.append(f"### 4. Complexity Analysis\n{complexity_analysis}")

        # 5. Potential issues
        if analysis.vulnerabilities:
            vuln_analysis = self._analyze_vulnerabilities(analysis.vulnerabilities)
            output_parts.append(f"### 5. Potential Issues\n{vuln_analysis}")

        # 6. Code suggestions
        suggestions = self._generate_suggestions(analysis)
        output_parts.append(f"### 6. Recommendations\n{suggestions}")

        return "\n\n".join(output_parts)

    def _get_instruction(self, analysis: CodeAnalysis) -> str:
        """Get instruction based on task type"""
        base_instruction = self.task_templates[self.task_type]["instruction"]

        # Customize based on code characteristics
        customizations = []

        if analysis.vulnerabilities:
            vuln_count = len(analysis.vulnerabilities)
            high_vulns = len([v for v in analysis.vulnerabilities if v.get('severity') == 'HIGH'])
            if high_vulns > 0:
                customizations.append(f"Pay special attention to {high_vulns} high-severity issues.")

        metrics = analysis.metrics
        if metrics.get('complexity', {}).get('average', 0) > 10:
            customizations.append("The code has high cyclomatic complexity.")

        if len(analysis.dfg_edges) > 50:
            customizations.append("The code has complex data dependencies.")

        if customizations:
            base_instruction += " " + " ".join(customizations)

        return base_instruction

    def _build_metadata(self, analysis: CodeAnalysis, index: int) -> Dict[str, Any]:
        """Build metadata"""
        # Calculate code hash
        code_hash = hashlib.md5(analysis.source_code.encode()).hexdigest()[:16]

        # Statistics
        stats = {
            "code_length": len(analysis.source_code),
            "lines_of_code": analysis.source_code.count('\n') + 1,
            "cfg_edges_count": len(analysis.cfg_edges),
            "dfg_edges_count": len(analysis.dfg_edges),
            "ast_nodes_count": len(analysis.ast_nodes),
            "vulnerabilities_count": len(analysis.vulnerabilities),
            "language": analysis.language,
            "function_name": analysis.function_name,
            "code_hash": code_hash
        }

        # Merge metrics
        if analysis.metrics:
            stats.update({
                "metrics": analysis.metrics,
                "avg_complexity": analysis.metrics.get('complexity', {}).get('average', 0),
                "max_complexity": analysis.metrics.get('complexity', {}).get('maximum', 0)
            })

        # Timestamp
        stats.update({
            "conversion_timestamp": datetime.now().isoformat(),
            "original_index": index,
            "model_type": self.model_type,
            "task_type": self.task_type
        })

        return stats

    def _format_ast_summary(self, ast_nodes: List[Dict[str, Any]]) -> str:
        """Format AST summary"""
        if not ast_nodes:
            return "No AST nodes available."

        # Count node types
        type_counts = defaultdict(int)
        for node in ast_nodes:
            node_type = node.get('label', 'unknown')
            type_counts[node_type] += 1

        # Get main nodes (top 10)
        top_nodes = sorted(ast_nodes, key=lambda x: x.get('order', 0))[:10]

        summary = f"Total AST Nodes: {len(ast_nodes)}\n"
        summary += "Node Type Distribution:\n"
        for node_type, count in sorted(type_counts.items(), key=lambda x: x[1], reverse=True)[:8]:
            summary += f"  - {node_type}: {count}\n"

        summary += "\nTop 10 Nodes (by order):\n"
        for i, node in enumerate(top_nodes, 1):
            node_type = node.get('label', 'unknown')
            code = node.get('code', '')[:50].replace('\n', ' ')
            line = node.get('lineNumber', 'N/A')
            summary += f"  {i}. [{line}] {node_type}: {code}\n"

        return summary

    def _format_cfg_summary(self, cfg_edges: List[Dict[str, Any]]) -> str:
        """Format CFG summary"""
        if not cfg_edges:
            return "No CFG edges available."

        # Count edge types
        edge_types = defaultdict(int)
        for edge in cfg_edges:
            edge_type = edge.get('edgeType', 'unknown')
            edge_types[edge_type] += 1

        # Get main edges (top 10)
        top_edges = cfg_edges[:10]

        summary = f"Total CFG Edges: {len(cfg_edges)}\n"
        summary += "Edge Type Distribution:\n"
        for edge_type, count in sorted(edge_types.items(), key=lambda x: x[1], reverse=True):
            summary += f"  - {edge_type}: {count}\n"

        summary += "\nTop 10 Control Flow Edges:\n"
        for i, edge in enumerate(top_edges, 1):
            src = edge.get('sourceCode', '')[:40].replace('\n', ' ')
            dst = edge.get('targetCode', '')[:40].replace('\n', ' ')
            summary += f"  {i}. {src} → {dst}\n"

        return summary

    def _format_dfg_summary(self, dfg_edges: List[Dict[str, Any]]) -> str:
        """Format DFG summary"""
        if not dfg_edges:
            return "No DFG edges available."

        # Count variables
        variable_counts = defaultdict(int)
        for edge in dfg_edges:
            variable = edge.get('variable', 'unknown')
            if variable:
                variable_counts[variable] += 1

        # Get main data flows (top 10)
        top_edges = dfg_edges[:10]

        summary = f"Total DFG Edges: {len(dfg_edges)}\n"
        summary += "Top Variables by Data Flow:\n"
        for variable, count in sorted(variable_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
            summary += f"  - {variable}: {count} edges\n"

        summary += "\nTop 10 Data Flow Edges:\n"
        for i, edge in enumerate(top_edges, 1):
            src = edge.get('sourceCode', '')[:40].replace('\n', ' ')
            dst = edge.get('targetCode', '')[:40].replace('\n', ' ')
            var = edge.get('variable', 'unknown')
            summary += f"  {i}. {src} → {dst} (var: {var})\n"

        return summary

    def _format_metrics(self, metrics: Dict[str, Any]) -> str:
        """Format metrics"""
        if not metrics:
            return "No metrics available."

        summary = ""

        # Basic metrics
        basic = metrics.get('basic', {})
        if basic:
            summary += "Basic Metrics:\n"
            for key, value in basic.items():
                summary += f"  - {key}: {value}\n"

        # Complexity
        complexity = metrics.get('complexity', {})
        if complexity:
            summary += "\nComplexity Metrics:\n"
            avg = complexity.get('average', 0)
            maximum = complexity.get('maximum', 0)
            summary += f"  - Average Cyclomatic Complexity: {avg:.2f}\n"
            summary += f"  - Maximum Cyclomatic Complexity: {maximum}\n"

        # Vulnerability severity
        vuln_severity = metrics.get('vulnerability_severity', {})
        if vuln_severity:
            summary += "\nVulnerability Severity:\n"
            for severity, count in vuln_severity.items():
                summary += f"  - {severity.upper()}: {count}\n"

        return summary.strip()

    def _generate_visualization_description(self, analysis: CodeAnalysis) -> str:
        """Generate visualization description"""
        description = []

        # CFG description
        cfg_edges = analysis.cfg_edges
        if cfg_edges:
            conditional_edges = [e for e in cfg_edges if 'CONDITIONAL' in e.get('edgeType', '')]
            call_edges = [e for e in cfg_edges if 'CALL' in e.get('edgeType', '')]

            description.append(f"Control Flow Graph has {len(cfg_edges)} edges:")
            if conditional_edges:
                description.append(f"  - {len(conditional_edges)} conditional branches")
            if call_edges:
                description.append(f"  - {len(call_edges)} function/method calls")

        # DFG description
        dfg_edges = analysis.dfg_edges
        if dfg_edges:
            variables = set(e.get('variable', '') for e in dfg_edges if e.get('variable'))
            description.append(
                f"Data Flow Graph shows data dependencies for {len(variables)} variables across {len(dfg_edges)} edges.")

        # AST description
        ast_nodes = analysis.ast_nodes
        if ast_nodes:
            node_types = set(n.get('label', '') for n in ast_nodes)
            description.append(
                f"Abstract Syntax Tree contains {len(ast_nodes)} nodes with {len(node_types)} different node types.")

        return "\n".join(description)

    def _analyze_function(self, analysis: CodeAnalysis) -> str:
        """Analyze function"""
        func_name = analysis.function_name
        code = analysis.source_code

        # Extract basic information
        lines = code.split('\n')
        param_pattern = r'\((.*?)\)'
        params = []

        for line in lines:
            if '(' in line and ')' in line and line.strip().endswith('{'):
                match = re.search(param_pattern, line)
                if match:
                    params = [p.strip() for p in match.group(1).split(',')]
                break

        # Analyze functionality
        analysis_text = f"Function `{func_name}` "
        if params:
            analysis_text += f"takes {len(params)} parameter(s): {', '.join(params[:3])}"
            if len(params) > 3:
                analysis_text += f" and {len(params) - 3} more"

        # Detect common patterns
        if 'malloc' in code or 'calloc' in code:
            analysis_text += "\n- Contains dynamic memory allocation"
        if 'free' in code:
            analysis_text += "\n- Contains memory deallocation"
        if 'printf' in code or 'fprintf' in code:
            analysis_text += "\n- Contains output operations"
        if 'if' in code or 'else' in code:
            analysis_text += "\n- Contains conditional logic"
        if 'for' in code or 'while' in code:
            analysis_text += "\n- Contains loops"
        if 'return' in code:
            analysis_text += "\n- Has explicit return statement(s)"

        return analysis_text

    def _analyze_control_flow(self, cfg_edges: List[Dict[str, Any]]) -> str:
        """Analyze control flow"""
        if not cfg_edges:
            return "No control flow information available."

        # Count different types
        edge_types = defaultdict(int)
        for edge in cfg_edges:
            edge_type = edge.get('edgeType', 'unknown')
            edge_types[edge_type] += 1

        analysis = f"Control flow consists of {len(cfg_edges)} edges:\n"

        for edge_type, count in sorted(edge_types.items()):
            if edge_type == 'CONDITIONAL':
                analysis += f"- {count} conditional branches\n"
            elif edge_type == 'CALL':
                analysis += f"- {count} function/method calls\n"
            elif edge_type == 'CFG_NEXT':
                analysis += f"- {count} sequential control flow edges\n"
            else:
                analysis += f"- {count} {edge_type.lower()} edges\n"

        # Detect loops
        if any('LOOP' in str(e.get('edgeType', '')) for e in cfg_edges):
            analysis += "- Contains loop structures\n"

        # Detect complex conditions
        conditional_edges = [e for e in cfg_edges if 'CONDITIONAL' in str(e.get('edgeType', ''))]
        if len(conditional_edges) > 3:
            analysis += f"- Has {len(conditional_edges)} conditional branches, indicating complex decision logic\n"

        return analysis.strip()

    def _analyze_data_flow(self, dfg_edges: List[Dict[str, Any]]) -> str:
        """Analyze data flow"""
        if not dfg_edges:
            return "No data flow information available."

        # Collect variable information
        variables = defaultdict(list)
        for edge in dfg_edges:
            var = edge.get('variable', 'unknown')
            if var and var != 'unknown':
                variables[var].append(edge)

        analysis = f"Data flow analysis shows {len(dfg_edges)} dependencies involving {len(variables)} variables:\n"

        # Analyze key variables
        for var, edges in sorted(variables.items(), key=lambda x: len(x[1]), reverse=True)[:5]:
            analysis += f"- Variable `{var}` has {len(edges)} data dependencies\n"

        # Detect data flow patterns
        if any('INPUT' in str(e.get('sourceCode', '')) for e in dfg_edges):
            analysis += "- Contains input data flows\n"

        if any('OUTPUT' in str(e.get('targetCode', '')) for e in dfg_edges):
            analysis += "- Contains output data flows\n"

        # Detect potential data contamination
        long_chains = []
        for var, edges in variables.items():
            if len(edges) > 5:
                long_chains.append(var)

        if long_chains:
            analysis += f"- Variables with complex data flows: {', '.join(long_chains[:3])}\n"

        return analysis.strip()

    def _analyze_complexity(self, metrics: Dict[str, Any]) -> str:
        """Analyze complexity"""
        complexity_data = metrics.get('complexity', {})
        avg_complexity = complexity_data.get('average', 0)
        max_complexity = complexity_data.get('maximum', 0)

        analysis = f"Cyclomatic Complexity Analysis:\n"
        analysis += f"- Average complexity: {avg_complexity:.2f}\n"
        analysis += f"- Maximum complexity: {max_complexity}\n"

        # Complexity assessment
        if avg_complexity < 5:
            analysis += "- Complexity is low (easy to maintain)\n"
        elif avg_complexity < 10:
            analysis += "- Complexity is moderate\n"
        elif avg_complexity < 20:
            analysis += "- Complexity is high (consider refactoring)\n"
        else:
            analysis += "- Complexity is very high (difficult to maintain and test)\n"

        # Other metrics
        basic_metrics = metrics.get('basic', {})
        if 'total_functions' in basic_metrics:
            analysis += f"- Total functions: {basic_metrics['total_functions']}\n"

        if 'total_cfg_edges' in basic_metrics:
            edges_per_func = basic_metrics['total_cfg_edges'] / max(basic_metrics.get('total_functions', 1), 1)
            analysis += f"- Average CFG edges per function: {edges_per_func:.1f}\n"

        return analysis.strip()

    def _analyze_vulnerabilities(self, vulnerabilities: List[Dict[str, Any]]) -> str:
        """Analyze vulnerabilities"""
        if not vulnerabilities:
            return "No vulnerabilities detected."

        # Group by severity
        by_severity = defaultdict(list)
        for vuln in vulnerabilities:
            severity = vuln.get('severity', 'MEDIUM')
            by_severity[severity].append(vuln)

        analysis = f"Detected {len(vulnerabilities)} potential issues:\n"

        for severity in ['HIGH', 'MEDIUM', 'LOW']:
            if severity in by_severity:
                vulns = by_severity[severity]
                analysis += f"\n{severity} severity ({len(vulns)}):\n"
                for i, vuln in enumerate(vulns[:3], 1):  # Show top 3
                    pattern = vuln.get('pattern', 'Unknown')
                    line = vuln.get('lineNumber', 'N/A')
                    desc = vuln.get('description', '')
                    analysis += f"  {i}. {pattern} (line {line}): {desc}\n"

                if len(vulns) > 3:
                    analysis += f"  ... and {len(vulns) - 3} more\n"

        # Summary
        high_count = len(by_severity.get('HIGH', []))
        if high_count > 0:
            analysis += f"\n⚠️  Critical: {high_count} high-severity issues need immediate attention."

        return analysis.strip()

    def _generate_suggestions(self, analysis: CodeAnalysis) -> str:
        """Generate improvement suggestions"""
        suggestions = []

        # Based on complexity
        metrics = analysis.metrics
        avg_complexity = metrics.get('complexity', {}).get('average', 0)
        if avg_complexity > 10:
            suggestions.append("Consider refactoring complex functions into smaller, more focused functions.")

        # Based on vulnerabilities
        if analysis.vulnerabilities:
            high_vulns = [v for v in analysis.vulnerabilities if v.get('severity') == 'HIGH']
            if high_vulns:
                suggestions.append("Address high-severity vulnerabilities immediately to prevent security issues.")

            buffer_vulns = [v for v in analysis.vulnerabilities if 'BUFFER' in v.get('pattern', '')]
            if buffer_vulns:
                suggestions.append(
                    "Replace unsafe string functions (strcpy, strcat) with safer alternatives (strncpy, strncat).")

        # Based on data flow complexity
        if len(analysis.dfg_edges) > 50:
            suggestions.append("Simplify data dependencies to improve code maintainability.")

        # Based on CFG structure
        cfg_edges = analysis.cfg_edges
        conditional_edges = [e for e in cfg_edges if 'CONDITIONAL' in str(e.get('edgeType', ''))]
        if len(conditional_edges) > 5:
            suggestions.append("Reduce nested conditionals to improve code readability.")

        # General suggestions
        suggestions.append("Add appropriate error handling for robustness.")
        suggestions.append("Include comments for complex logic sections.")
        suggestions.append("Consider adding unit tests for critical code paths.")

        if not suggestions:
            suggestions.append("Code structure appears good. Maintain current coding practices.")

        return "\n".join([f"- {s}" for s in suggestions])

    def _truncate_input(self, input_text: str, analysis: CodeAnalysis) -> str:
        """Intelligently truncate input text"""
        sections = input_text.split('\n\n')

        # Priority: keep code
        code_section = sections[0] if sections else ""

        # Keep key summaries
        important_sections = []
        for section in sections[1:]:
            if section.startswith('## Abstract Syntax Tree'):
                # Keep only first part of AST summary
                lines = section.split('\n')
                important_sections.append('\n'.join(lines[:15]))
            elif section.startswith('## Control Flow Graph'):
                lines = section.split('\n')
                important_sections.append('\n'.join(lines[:10]))
            elif section.startswith('## Function Information'):
                important_sections.append(section)

        # Combine and ensure within limits
        truncated = [code_section] + important_sections
        result = '\n\n'.join(truncated)

        if len(result) > self.max_input_length:
            # Further truncation
            result = result[:self.max_input_length]
            result = result.rsplit('\n', 1)[0] + "\n\n[Input truncated due to length constraints...]"

        return result


class DatasetBuilder:
    """Dataset builder"""

    def __init__(self, converter: AlpacaConverter):
        self.converter = converter
        self.dataset = []

    def load_from_json(self, file_path: str) -> List[Dict[str, Any]]:
        """Load analysis results from JSON file"""
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        if isinstance(data, dict):
            # Single result
            return [self._parse_analysis_result(data)]
        elif isinstance(data, list):
            # Multiple results
            return [self._parse_analysis_result(item) for item in data]
        else:
            raise ValueError(f"Unsupported data format in {file_path}")

    def load_from_directory(self, dir_path: str) -> List[CodeAnalysis]:
        """Load multiple analysis results from directory"""
        analyses = []
        dir_path = Path(dir_path)

        for json_file in dir_path.glob("*.json"):
            try:
                file_analyses = self.load_from_json(str(json_file))
                analyses.extend(file_analyses)
                logger.info(f"Loaded {len(file_analyses)} analyses from {json_file.name}")
            except Exception as e:
                logger.error(f"Failed to load {json_file}: {e}")

        return analyses

    def _parse_analysis_result(self, data: Dict[str, Any]) -> CodeAnalysis:
        """Parse analysis result data"""
        # Handle different input formats
        source_code = data.get('input', data.get('source_code', data.get('code', '')))

        # Extract function name
        function_name = data.get('function_name', 'unknown')
        if function_name == 'unknown' and 'functions' in data:
            # Try to extract from function list
            functions = data.get('functions', [])
            if functions and isinstance(functions, list):
                if isinstance(functions[0], dict):
                    function_name = functions[0].get('name', 'unknown')

        # Extract CFG edges
        cfg_edges = data.get('cfg_edges', data.get('cfgEdges', []))
        if isinstance(cfg_edges, str):
            try:
                cfg_edges = json.loads(cfg_edges)
            except:
                cfg_edges = []

        # Extract DFG edges
        dfg_edges = data.get('dfg_edges', data.get('dfgEdges', []))
        if isinstance(dfg_edges, str):
            try:
                dfg_edges = json.loads(dfg_edges)
            except:
                dfg_edges = []

        # Extract AST nodes
        ast_nodes = data.get('ast_nodes', data.get('astNodes', []))
        if isinstance(ast_nodes, str):
            try:
                ast_nodes = json.loads(ast_nodes)
            except:
                ast_nodes = []

        # Extract vulnerabilities
        vulnerabilities = data.get('vulnerabilities', [])

        # Extract metrics
        metrics = data.get('metrics', data.get('metrics_data', {}))

        # Extract filename
        filename = data.get('filename', data.get('fileName', None))

        return CodeAnalysis(
            source_code=source_code,
            function_name=function_name,
            cfg_edges=cfg_edges,
            dfg_edges=dfg_edges,
            ast_nodes=ast_nodes,
            vulnerabilities=vulnerabilities,
            metrics=metrics,
            filename=filename
        )

    def build_dataset(
            self,
            analyses: List[CodeAnalysis],
            start_index: int = 0
    ) -> List[AlpacaItem]:
        """Build dataset"""
        dataset = []

        for i, analysis in enumerate(analyses):
            try:
                alpaca_item = self.converter.convert_analysis_to_alpaca(analysis, start_index + i)
                dataset.append(alpaca_item)

                if (i + 1) % 10 == 0:
                    logger.info(f"Processed {i + 1}/{len(analyses)} items")

            except Exception as e:
                logger.error(f"Failed to convert analysis {i}: {e}")
                continue

        logger.info(f"Successfully converted {len(dataset)}/{len(analyses)} items")
        return dataset

    def save_dataset(
            self,
            dataset: List[AlpacaItem],
            output_path: str,
            format: str = "alpaca"
    ):
        """Save dataset"""
        output_path = Path(output_path)

        # Convert to list of dictionaries
        data_dicts = []
        for item in dataset:
            item_dict = asdict(item)

            # Adjust based on format
            if format == "codellama":
                # CodeLlama format
                item_dict = {
                    "text": f"### Instruction:\n{item.instruction}\n\n### Input:\n{item.input}\n\n### Response:\n{item.output}",
                    "metadata": item.metadata
                }
            elif format == "vicuna":
                # Vicuna format
                item_dict = {
                    "conversations": [
                        {"from": "human", "value": f"{item.instruction}\n\n{item.input}"},
                        {"from": "assistant", "value": item.output}
                    ],
                    "metadata": item.metadata
                }
            else:
                # Standard Alpaca format
                item_dict = {
                    "instruction": item.instruction,
                    "input": item.input,
                    "output": item.output,
                    "metadata": item.metadata
                }

            data_dicts.append(item_dict)

        # Save as JSON
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data_dicts, f, indent=2, ensure_ascii=False)

        # Also save statistics
        stats_file = output_path.parent / f"{output_path.stem}_stats.json"
        stats = self._generate_statistics(dataset)
        with open(stats_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)

        logger.info(f"Dataset saved to {output_path}")
        logger.info(f"Statistics saved to {stats_file}")

    def _generate_statistics(self, dataset: List[AlpacaItem]) -> Dict[str, Any]:
        """Generate dataset statistics"""
        if not dataset:
            return {"message": "Empty dataset"}

        stats = {
            "total_items": len(dataset),
            "total_instructions": len(set(item.instruction for item in dataset)),
            "avg_input_length": sum(len(item.input) for item in dataset) / len(dataset),
            "avg_output_length": sum(len(item.output) for item in dataset) / len(dataset),
            "input_length_distribution": self._calculate_length_distribution([item.input for item in dataset]),
            "output_length_distribution": self._calculate_length_distribution([item.output for item in dataset]),
            "task_types": defaultdict(int),
            "languages": defaultdict(int),
            "function_counts": defaultdict(int)
        }

        # Collect metadata statistics
        for item in dataset:
            metadata = item.metadata

            # Task type
            task_type = metadata.get('task_type', 'unknown')
            stats['task_types'][task_type] += 1

            # Language
            language = metadata.get('language', 'unknown')
            stats['languages'][language] += 1

            # Function name
            func_name = metadata.get('function_name', 'unknown')
            stats['function_counts'][func_name] += 1

        return stats

    def _calculate_length_distribution(self, texts: List[str]) -> Dict[str, int]:
        """Calculate text length distribution"""
        distribution = defaultdict(int)
        for text in texts:
            length = len(text)
            if length < 100:
                distribution["<100"] += 1
            elif length < 500:
                distribution["100-500"] += 1
            elif length < 1000:
                distribution["500-1000"] += 1
            elif length < 2000:
                distribution["1000-2000"] += 1
            else:
                distribution[">2000"] += 1
        return dict(distribution)


def main():
    """Main function"""
    parser = argparse.ArgumentParser(
        description="Convert code analysis results to Alpaca format dataset",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument(
        '--input', '-i',
        required=True,
        help='Input file or directory (JSON format analysis results)'
    )
    parser.add_argument(
        '--output', '-o',
        default='alpaca_dataset.json',
        help='Output file path (default: alpaca_dataset.json)'
    )
    parser.add_argument(
        '--format', '-f',
        choices=['alpaca', 'codellama', 'vicuna'],
        default='alpaca',
        help='Output format (default: alpaca)'
    )
    parser.add_argument(
        '--task-type', '-t',
        choices=['code_understanding', 'vulnerability_detection', 'code_summarization', 'code_generation'],
        default='code_understanding',
        help='Task type for instruction generation'
    )
    parser.add_argument(
        '--max-length', '-m',
        type=int,
        default=2048,
        help='Maximum input length (default: 2048)'
    )
    parser.add_argument(
        '--model-type',
        default='codellama',
        choices=['codellama', 'alpaca', 'vicuna', 'llama'],
        help='Target model type (default: codellama)'
    )
    parser.add_argument(
        '--include-viz',
        action='store_true',
        help='Include visualization descriptions'
    )
    parser.add_argument(
        '--max-items',
        type=int,
        default=None,
        help='Maximum number of items to process (for testing)'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose logging'
    )

    args = parser.parse_args()

    # Set log level
    if args.verbose:
        logger.setLevel(logging.DEBUG)

    # Display configuration
    logger.info("=" * 60)
    logger.info("Alpaca Format Converter")
    logger.info("=" * 60)
    logger.info(f"Input: {args.input}")
    logger.info(f"Output: {args.output}")
    logger.info(f"Format: {args.format}")
    logger.info(f"Task: {args.task_type}")
    logger.info(f"Model: {args.model_type}")
    logger.info(f"Max length: {args.max_length}")
    logger.info("=" * 60)

    # Initialize converter
    converter = AlpacaConverter(
        model_type=args.model_type,
        max_input_length=args.max_length,
        include_visualization=args.include_viz,
        task_type=args.task_type
    )

    # Initialize builder
    builder = DatasetBuilder(converter)

    try:
        # Load analyses
        input_path = Path(args.input)
        if input_path.is_file():
            logger.info(f"Loading analysis results from file: {args.input}")
            analyses = builder.load_from_json(args.input)
        elif input_path.is_dir():
            logger.info(f"Loading analysis results from directory: {args.input}")
            analyses = builder.load_from_directory(args.input)
        else:
            logger.error(f"Input path does not exist: {args.input}")
            sys.exit(1)

        # Limit if specified
        if args.max_items and args.max_items < len(analyses):
            analyses = analyses[:args.max_items]
            logger.info(f"Limited to {args.max_items} items")

        logger.info(f"Loaded {len(analyses)} analysis results")

        # Convert to Alpaca format
        logger.info("Converting to Alpaca format...")
        dataset = builder.build_dataset(analyses)

        # Save dataset
        logger.info("Saving dataset...")
        builder.save_dataset(dataset, args.output, args.format)

        # Print summary
        logger.info("=" * 60)
        logger.info("CONVERSION COMPLETE")
        logger.info("=" * 60)
        logger.info(f"Total converted: {len(dataset)} items")
        logger.info(f"Output file: {args.output}")

        # Calculate and display statistics
        avg_input_len = sum(len(item.input) for item in dataset) / max(len(dataset), 1)
        avg_output_len = sum(len(item.output) for item in dataset) / max(len(dataset), 1)

        logger.info(f"Average input length: {avg_input_len:.0f} characters")
        logger.info(f"Average output length: {avg_output_len:.0f} characters")

        if dataset:
            sample = dataset[0]
            logger.info("\nSample item (first 200 chars of input):")
            logger.info(f"Instruction: {sample.instruction[:100]}...")
            logger.info(f"Input preview: {sample.input[:200]}...")
            logger.info(f"Output preview: {sample.output[:200]}...")

        logger.info("=" * 60)

    except Exception as e:
        logger.error(f"Conversion failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()