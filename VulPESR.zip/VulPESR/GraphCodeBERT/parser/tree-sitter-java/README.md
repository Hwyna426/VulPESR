tree-sitter-java
================

[![Build/test](https://github.com/tree-sitter/tree-sitter-java/actions/workflows/ci.yml/badge.svg)](https://github.com/tree-sitter/tree-sitter-java/actions/workflows/ci.yml)

Java grammar for [tree-sitter](https://github.com/tree-sitter/tree-sitter).
